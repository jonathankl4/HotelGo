<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            "name"=>"jojo",
            "email"=>"jokris2002@gmail.com",
            "email_verified_at"=>now(),
            "password"=>'123', //mxzero
            "role"=>0
        ]);
        User::create([
            "name"=>"edward",
            "email"=>"edward@gmail.com",
            "email_verified_at"=>now(),
            "password"=>'123', //mxzero
            "role"=>1
        ]);
    }
}

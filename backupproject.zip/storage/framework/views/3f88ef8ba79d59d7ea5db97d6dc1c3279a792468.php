<?php $__env->startSection("title", "Dashboard"); ?>


<?php $__env->startSection("content"); ?>

<h1>Tambah Kamar Baru</h1>
<form action="<?php echo e(url('/admin/tambahkamar')); ?>" method="post">
    <?php echo csrf_field(); ?>
    Nama Kamar
    <input type="text" class="form-control" style="width: 400px" name="namakamar">
    <span style="color: red;"><?php echo e($errors->first('namakamar')); ?></span>
    <br>
    Tipe Kamar
    <select  id="" class="form-select" style="width: 400px" name="tipekamar">
        <option value="standart">Standart</option>
        <option value="superior">Superior</option>
        <option value="vip">Vip</option>
    </select>
    <br>
    Jumlah Kamar
    <input type="text" class="form-control" style="width: 400px" name="jumlahkamar">
    <span style="color: red;"><?php echo e($errors->first('jumlahkamar')); ?></span>
    <br>
    Jumlah Penghuni
    <input type="text" class="form-control" style="width: 400px" name="jumlahpenghuni">
    <span style="color: red;"><?php echo e($errors->first('jumlahpenghuni')); ?></span>
    <br>
    Tipe Ranjang
    <select  id="" class="form-select" style="width: 400px" name="tiperanjang">
        <option value="single">Single Bed</option>
        <option value="twin">Twin Bed</option>
        <option value="queen">Queen Bed</option>
        <option value="king`">King Bed</option>
    </select>
    <br>
    Harga
    <input type="text" class="form-control" style="width: 400px" name="hargakamar">
    <span style="color: red;"><?php echo e($errors->first('hargakamar')); ?></span>
    <br>
    <button class="btn btn-success">Tambah</button>






</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.sidebaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Proyek Probis\resources\views/admin/HtambahKamar.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title", "Dashboard"); ?>


<?php $__env->startSection("content"); ?>



<h1>Master Kamar</h1>
<a href="<?php echo e(url('/admin/HtambahKamar')); ?>"><button class="btn btn-success">Tambah kamar</button></a>

<table class="table table-info">
    <thead>
      <tr>
        <th scope="col"></th>
        <th scope="col">First</th>
        <th scope="col">Last</th>
        <th scope="col">Handle</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Mark</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>

    </tbody>
  </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.sidebaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Proyek Probis\resources\views/admin/HMasterKamar.blade.php ENDPATH**/ ?>
<?php $__env->startSection("title", "Dashboard"); ?>


<?php $__env->startSection("content"); ?>


<h1>Welcome Admin</h1>
<h1>Dashboard</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.sidebaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\Proyek Probis\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
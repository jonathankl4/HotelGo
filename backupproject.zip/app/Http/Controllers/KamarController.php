<?php

namespace App\Http\Controllers;

use App\Models\Kamar;
use Illuminate\Http\Request;

class KamarController extends Controller
{
    //

    public function tambahkamar(Request $req){

        if ($req->validate(
            [
                "namakamar" => "required",
                "jumlahkamar" => "required|integer|min:1",
                "jumlahpenghuni" => "required|integer|min:1",
                "hargakamar" => "required|integer|min:1"

            ],
            [
                "required" => "Field diatas harus di isi !",
                "integer" => "Field diatas harus di isi angka"

            ]
        )) {
            # code...
            $nk = new Kamar();
            $nk->nama_kamar = $req->namakamar;
            $nk->tipe_kamar = $req->tipekamar;
            $nk->jumlah_kamar = $req->jumlahkamar;
            $nk->jumlah_penghuni = $req->jumlahpenghuni;
            $nk->tipe_ranjang = $req->tiperanjang;
            $nk->harga_kamar = $req->hargakamar;
            $nk->save();

            return redirect("/MasterKamar")->with("success", "Berhasil Tambah Kamar");


        }
    }
}

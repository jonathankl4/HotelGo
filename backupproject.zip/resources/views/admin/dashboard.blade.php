@extends('template.sidebaradmin')

@section("title", "Dashboard")


@section("content")


<h1>Welcome Admin</h1>
<h1>Dashboard</h1>

@endsection


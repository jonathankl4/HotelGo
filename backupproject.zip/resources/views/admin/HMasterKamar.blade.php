@extends('template.sidebaradmin')
@section("title", "Dashboard")


@section("content")


{{-- <h1>Welcome Admin</h1> --}}
<h1>Master Kamar</h1>
<a href="{{url('/admin/HtambahKamar')}}"><button class="btn btn-success">Tambah kamar</button></a>

<table class="table table-info">
    <thead>
      <tr>
        <th scope="col"></th>
        <th scope="col">First</th>
        <th scope="col">Last</th>
        <th scope="col">Handle</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Mark</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>

    </tbody>
  </table>

  @if (session()->has("success"))
<x-toast title="Success" type="success">{{ session("success") }}</x-toast>
@elseif(session()->has("error"))
<x-toast title="Error" type="danger">{{ session("error") }}</x-toast>
@endif
@stop


@endsection

